# 统计 1.2 文件夹中图片数量多余 20 的文件夹个数，并将其拷贝出来。
import os
import shutil

path = 'F:/培训数据/1.2数据/'
dst = 'F:/test'
for src, dirnames, filenames in os.walk(path):
    count = 0
    dst = os.path.basename(src)
    dest = 'F:/test/' + dst
    # print(dest)
    for file in filenames:
        count += 1
    if count > 20:
        print(src, '----->',dest)
        shutil.copytree(src,dest)
