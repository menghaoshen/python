# 4 通过 python 读写 excel
# 作业：
# 1、读取 csv 中的第 12 列，并统计检查部位有多少种。
# 2、将统计的检查部位存入到一个新 scv 中，保存格式如：
# 第一列部位 第二列数量
# [胸部,平扫] 301
# [胸部,平扫+增强] 109
import csv
import re


with open('F:/培训数据/1.4数据/data805.csv', 'r', encoding='utf8', newline='') as csvfile:
    reader = csv.reader(csvfile)
    demon = open('./demon.csv', 'w', newline='', encoding='utf8')
    w = csv.writer(demon)
    d = ['第一列部位','第二列数量']
    w.writerow(d)
    for r, rows in enumerate(reader):
        if r == 12:
            row = rows[11]
            list1 = row.split(' ')
            print('第12列的检查的部位一共有{}种'.format(len(list1)))
            d = []
            nums = len(list1)
            d.append(list1)
            d.append(nums)
            w.writerow(d)

        else:
            d = []
            row = rows[11]
            list1 = row.split(' ')
            nums = len(list1)
            d.append(list1)
            d.append(nums)
            w.writerow(d)
demon.close()
csvfile.close()
