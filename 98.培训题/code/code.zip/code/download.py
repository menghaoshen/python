import shutil
from database import DB

db = DB()
message = db.get_data()
db.close()
paths = [one[1] for one in message]

for path in paths:
    shutil.copytree()