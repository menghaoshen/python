
class DB:
    def __init__(self,server, user, password, database):
        # server    数据库服务器名称或IP
        # user      用户名
        # password  密码
        # database  数据库名称
        import pymssql
        conn = pymssql.connect(server, user, password, database)
        cursor = conn.cursor()

    def get_data(self):
        # 查询操作
        cursor.execute("select user_id, user_name from users")
        rows = cursor.fetchall()
        return rows

    def close(self):
        # 关闭连接
        conn.close()